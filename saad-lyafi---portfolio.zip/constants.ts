
import { Project, ExperienceItem, EducationItem, SkillItem } from './types';

export const PORTFOLIO_ITEMS: Project[] = [
  {
    id: 8,
    title: "AI Narrative Production",
    category: "AI / Video Production",
    image: "https://iili.io/fD7yVta.jpg",
    likes: 2890,
    comments: 145,
    description: "A high-fidelity cinematic video production workflow where generative AI creates the core visual assets, followed by meticulous editing and motion graphics in Adobe Premiere Pro and After Effects.",
    tags: ["AI Video", "Premiere Pro", "After Effects"]
  },
  {
    id: 1,
    title: "Punk.ma Article Carousel",
    category: "PUNK.ma / Social Content",
    image: "https://iili.io/fD7hNMN.jpg",
    likes: 5120,
    comments: 342,
    description: "High-engagement digital media carousel designed for Punk.ma social platforms. Fully crafted using Adobe Photoshop to combine cinematic visuals with punchy typography.",
    tags: ["Photoshop", "Social Media", "Carousel"]
  },
  {
    id: 2,
    title: "PUNK.ma Social History",
    category: "PUNK.ma / Digital Storytelling",
    image: "https://iili.io/fDYzkBV.jpg",
    likes: 3120,
    comments: 89,
    description: "Advanced Instagram carousel exploring historical narratives. Designed in Photoshop and animated in After Effects to create a high-impact 'post history' experience for digital audiences.",
    tags: ["Photoshop", "After Effects", "Instagram"]
  },
  {
    id: 3,
    title: "Bombe nucléaire à Sidi Slimane",
    category: "PUNK.ma / Narrative Design",
    image: "https://iili.io/fD7nuFn.jpg",
    likes: 3800,
    comments: 112,
    description: "Historical storytelling piece about the 1958 B-52 incident. Designed to capture tension and historical weight through cinematic image processing.",
    tags: ["Historical Content", "Visual Storytelling", "Photoshop"]
  },
  {
    id: 7,
    title: "Carré 18 Party",
    category: "Event Promotion",
    image: "https://iili.io/fD7MMhB.jpg",
    likes: 1540,
    comments: 82,
    description: "Vibrant event promotional visual created for a Carré 18 community gathering. This high-impact asset was made by Canva to showcase rapid, high-quality production.",
    tags: ["Canva", "Event Poster", "Social Media"]
  },
  {
    id: 4,
    title: "Lesiteinfo Digital Identity",
    category: "Social Media Strategy",
    image: "https://images.unsplash.com/photo-1572044162444-ad60f128bdea?q=80&w=800&auto=format&fit=crop",
    likes: 942,
    comments: 32,
    description: "Core visual branding and social content ecosystem for one of Morocco's premier news platforms.",
    tags: ["Branding", "News Media", "Strategy"]
  },
  {
    id: 5,
    title: "AI-Automated Production",
    category: "AI Automation",
    image: "https://images.unsplash.com/photo-1633167606207-d840b5070fc2?q=80&w=800&auto=format&fit=crop",
    likes: 1120,
    comments: 45,
    description: "Implementation of AI tools to scale high-quality video and image production workflows for digital brands.",
    tags: ["AI Tools", "Workflow", "Automation"]
  },
  {
    id: 6,
    title: "Carré 18 Community Strategy",
    category: "Community Management",
    image: "https://images.unsplash.com/photo-1460925895917-afdab827c52f?q=80&w=800&auto=format&fit=crop",
    likes: 670,
    comments: 15,
    description: "Engaging a high-energy sports community through interactive content, polls, and live event coverage.",
    tags: ["Engagement", "Sports", "Growth"]
  },
];

export const HIGHLIGHTS = [
  { id: 1, label: "Social", icon: "📱" },
  { id: 2, label: "Design", icon: "🎨" },
  { id: 3, label: "Video", icon: "🎬" },
  { id: 4, label: "AI Tools", icon: "🤖" },
  { id: 5, label: "Ads", icon: "📈" },
  { id: 6, label: "SEO", icon: "🔍" },
];

export const EXPERIENCE_DATA: ExperienceItem[] = [
  {
    id: 1,
    role: "Social Media Specialist & Content Manager",
    company: "Punk.ma / Carré 18 - Digital Media & Sports Content",
    period: "2022 - Present",
    description: [
      "Manage daily social media content for Carré 18, including publishing, caption writing, and community engagement.",
      "Edit short-form video content using Adobe Premiere Pro and Canva.",
      "Design visuals and perform image editing using Adobe Photoshop and Illustrator.",
      "Create video content using AI-generated footage to support storytelling and production efficiency.",
      "Support boosted and paid social media posts, including content adaptation and performance monitoring.",
      "Track engagement metrics and assist with content optimization and reporting."
    ],
    type: "Digital Media"
  },
  {
    id: 2,
    role: "Social Media Specialist & Graphic Designer",
    company: "Lesiteinfo.ma - Online Media",
    period: "2017 - 2024",
    description: [
      "Managed daily social media publishing across Facebook, Instagram, and Tiktok.",
      "Edited short-form video content for social platforms to support engagement and reach.",
      "Designed visuals and performed image editing using Adobe Photoshop and Canva.",
      "Supported boosted and paid social posts, including creative adaptation and performance follow-up.",
      "Assisted with analytics tracking, reporting, and content optimization.",
      "Applied basic SEO principles when creating captions and supporting content (keywords, readability, headlines)."
    ],
    type: "Online Media"
  },
  {
    id: 3,
    role: "Warehouse Technician & Design Support (AutoCAD Trainee)",
    company: "Additional Experience - Canada",
    period: "2024 - Present",
    description: [
      "Support design documentation and AutoCAD updates.",
      "Maintain organized workflows, inventory, and ERP records (Odoo)."
    ],
    type: "Design Support"
  }
];

export const EDUCATION_DATA: EducationItem[] = [
  { id: 1, degree: "AutoCAD Certificate (In Progress) - George Brown College", year: "2024 - Present" },
  { id: 2, degree: "Master's Degree - Strategic Marketing", year: "2016 - 2018" },
  { id: 3, degree: "Bachelor's Degree - Digital Marketing", year: "2015 - 2016" },
];

export const SKILLS_DATA: SkillItem[] = [
  { category: "Core Social Media", items: ["Social Media Management", "Content Publishing", "Copywriting", "Caption Writing", "Community Management", "Social Media Analytics", "Reporting", "Boosted & Paid Social Support"] },
  { category: "Video & Visual", items: ["Video Editing (Reels, Youtube, TikTok, Shorts)", "Canva (Social Media Assets & Video)", "Adobe Photoshop", "Adobe Illustrator", "Adobe After Effects", "Adobe Premiere Pro", "Adobe Lightroom"] },
  { category: "AI & Automation", items: ["AI-Assisted Video Footage Creation", "AI-Supported Ideation & Editing", "Workflow Automation (n8n - Beginner)"] },
  { category: "Platforms & Tools", items: ["Meta Business Manager", "Google Ads (Basic)", "Hootsuite", "Sprinklr", "Microsoft Excel", "Word", "PowerPoint", "AutoCAD (Trainee)"] }
];

export const SKILL_LEVELS = [
  { label: "Content Strategy", level: 95, color: "bg-punk-cyan" },
  { label: "Visual Design", level: 90, color: "bg-punk-yellow" },
  { label: "Video Production", level: 85, color: "bg-punk-accent" },
  { label: "AI Automation", level: 80, color: "bg-white" },
  { label: "Media Analytics", level: 75, color: "bg-zinc-500" },
];
