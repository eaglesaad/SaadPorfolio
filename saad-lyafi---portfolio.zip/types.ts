export interface Project {
  id: number;
  title: string;
  category: string;
  image: string;
  likes: number;
  comments: number;
  description: string;
  tags: string[];
}

export interface NavItem {
  label: string;
  id: ViewState;
  icon: any;
}

export type ViewState = 'portfolio' | 'resume' | 'ai-studio' | 'about';

export interface AIResponse {
  headline: string;
  caption: string;
  visualConcept: string;
  hashtags: string[];
}

export interface ExperienceItem {
  id: number;
  role: string;
  company: string;
  period: string;
  description: string[];
  type: string; 
}

export interface EducationItem {
  id: number;
  degree: string;
  year: string;
}

export interface SkillItem {
  category: string;
  items: string[];
}