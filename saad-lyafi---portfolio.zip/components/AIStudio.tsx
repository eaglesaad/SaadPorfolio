
import React, { useState } from 'react';
import { GoogleGenAI, Type } from "@google/genai";
import { Sparkles, Zap, Aperture, Copy, Loader2 } from 'lucide-react';
import { AIResponse } from '../types';

const AIStudio: React.FC = () => {
  const [topic, setTopic] = useState('');
  const [tone, setTone] = useState('Sarcastic & Dark');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<AIResponse | null>(null);

  const generateContent = async () => {
    if (!topic) return;
    setLoading(true);
    setResult(null);

    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY! });
      
      const prompt = `
        Act as a creative director for a high-end digital media agency. 
        Create a social media content brief for: "${topic}".
        Tone: ${tone}.
        
        Return JSON with:
        - headline: Catchy, uppercase.
        - caption: Engaging 2-sentence caption.
        - visualConcept: Description for a graphic designer.
        - hashtags: 3-5 relevant hashtags.
      `;

      const response = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: prompt,
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              headline: { type: Type.STRING },
              caption: { type: Type.STRING },
              visualConcept: { type: Type.STRING },
              hashtags: { type: Type.ARRAY, items: { type: Type.STRING } }
            }
          }
        }
      });

      if (response.text) {
        setResult(JSON.parse(response.text));
      }
    } catch (error) {
      console.error("AI failed", error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto p-6">
      <div className="bg-zinc-950 border border-zinc-800 p-8 relative">
        <div className="flex items-center gap-3 mb-8">
          <Zap className="text-punk-yellow" size={24} />
          <h2 className="text-2xl font-display uppercase tracking-widest text-white">AI Automation Lab</h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <div className="md:col-span-2">
            <label className="block text-[10px] font-mono font-bold uppercase text-zinc-500 mb-2">Topic</label>
            <input 
              type="text" 
              value={topic}
              onChange={(e) => setTopic(e.target.value)}
              placeholder="Latest news or brand event..."
              className="w-full bg-black border border-zinc-800 p-3 text-sm text-white focus:border-punk-cyan focus:outline-none font-mono"
            />
          </div>
          <div>
            <label className="block text-[10px] font-mono font-bold uppercase text-zinc-500 mb-2">Voice</label>
            <select 
              value={tone}
              onChange={(e) => setTone(e.target.value)}
              className="w-full bg-black border border-zinc-800 p-3 text-sm text-white focus:border-punk-cyan focus:outline-none font-mono"
            >
              <option>Professional</option>
              <option>Edgy & Viral</option>
              <option>Sarcastic</option>
            </select>
          </div>
        </div>

        <button 
          onClick={generateContent}
          disabled={loading || !topic}
          className="w-full py-3 bg-punk-cyan text-black font-mono font-bold uppercase text-xs tracking-widest hover:bg-white transition-all disabled:opacity-50"
        >
          {loading ? 'Analyzing...' : 'Generate Creative Brief'}
        </button>

        {result && (
          <div className="mt-10 pt-10 border-t border-zinc-900 animate-in fade-in">
            <div className="mb-6">
              <span className="text-punk-yellow text-[10px] font-mono font-bold uppercase">Headline</span>
              <h3 className="text-3xl font-display text-white mt-1 uppercase tracking-tight">{result.headline}</h3>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
              <div>
                <span className="text-zinc-500 text-[10px] font-mono font-bold uppercase">Copy</span>
                <p className="text-sm text-gray-400 mt-2 font-mono leading-relaxed">{result.caption}</p>
              </div>
              <div className="bg-zinc-900/50 p-4 border-l-2 border-punk-accent">
                <span className="text-zinc-500 text-[10px] font-mono font-bold uppercase">Visual Concept</span>
                <p className="text-xs text-gray-300 mt-2 italic">"{result.visualConcept}"</p>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default AIStudio;
