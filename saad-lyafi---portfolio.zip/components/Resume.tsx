
import React, { useEffect, useState } from 'react';
import { EXPERIENCE_DATA, EDUCATION_DATA, SKILLS_DATA, SKILL_LEVELS } from '../constants';
import { Briefcase, GraduationCap, Code, Languages, Globe, BarChart3 } from 'lucide-react';

const SkillBar: React.FC<{ label: string; level: number; color: string }> = ({ label, level, color }) => {
  const [width, setWidth] = useState(0);

  useEffect(() => {
    const timer = setTimeout(() => setWidth(level), 200);
    return () => clearTimeout(timer);
  }, [level]);

  return (
    <div className="mb-6">
      <div className="flex justify-between items-center mb-1">
        <span className="font-mono text-xs uppercase font-bold tracking-widest text-gray-300">{label}</span>
        <span className="font-mono text-[10px] text-gray-500">{level}%</span>
      </div>
      <div className="h-2 w-full bg-zinc-900 overflow-hidden border border-zinc-800 relative">
        <div 
          className={`h-full ${color} transition-all duration-1000 ease-out shadow-[0_0_10px_currentColor]`}
          style={{ width: `${width}%` }}
        ></div>
        {/* Animated Glitch/Scanline effect on bar */}
        <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/10 to-transparent w-20 animate-[move-scan_2s_infinite]"></div>
      </div>
    </div>
  );
};

const Resume: React.FC = () => {
  return (
    <div className="max-w-4xl mx-auto p-4 md:p-8 animate-in slide-in-from-bottom-4 duration-700">
      
      {/* Profile Summary Hook */}
      <div className="mb-12 bg-zinc-950 p-8 border-l-4 border-punk-cyan relative overflow-hidden group">
        <div className="absolute top-0 right-0 p-2 opacity-10 group-hover:opacity-20 transition-opacity">
          <Globe size={80} className="text-punk-cyan" />
        </div>
        <h2 className="text-punk-cyan font-display uppercase text-sm mb-4 tracking-[0.2em]">Profile Summary</h2>
        <p className="text-gray-300 leading-relaxed font-mono text-sm relative z-10">
          Social Media Specialist with 7+ years of experience managing social platforms and producing visual and video content for digital media brands. 
          Experienced in AI-assisted video creation to support storytelling and production efficiency. 
          Hands-on with daily posting, boosted posts, basic SEO practices, and analytics tracking.
        </p>
      </div>

      {/* Experience Section */}
      <div className="mb-16">
        <div className="flex items-center gap-3 mb-8 border-b border-zinc-900 pb-2">
          <Briefcase className="text-punk-yellow" size={28} />
          <h2 className="text-3xl font-display uppercase tracking-wider">Work Experience</h2>
        </div>

        <div className="relative border-l-2 border-zinc-900 ml-3 md:ml-6 space-y-12">
          {EXPERIENCE_DATA.map((job) => (
            <div key={job.id} className="relative pl-8 md:pl-12">
              <div className="absolute -left-[9px] top-2 w-4 h-4 rounded-full bg-punk-black border-2 border-punk-cyan"></div>
              
              <div className="flex flex-col md:flex-row md:items-baseline justify-between mb-2">
                <h3 className="text-xl md:text-2xl font-bold text-white group-hover:text-punk-cyan transition-colors">
                  {job.role}
                </h3>
                <span className="font-mono text-sm text-punk-yellow bg-zinc-900 px-3 py-1 rounded-sm">
                  {job.period}
                </span>
              </div>
              
              <div className="text-lg text-gray-500 font-display uppercase mb-4 tracking-wide">
                {job.company}
              </div>

              <ul className="space-y-3">
                {job.description.map((desc, idx) => (
                  <li key={idx} className="text-gray-400 text-sm md:text-base leading-relaxed flex items-start gap-3">
                    <span className="text-punk-cyan mt-1.5 font-bold text-[10px]">▶</span>
                    {desc}
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </div>

      {/* Skills Visualization Section */}
      <div className="mb-16">
        <div className="flex items-center gap-3 mb-10 border-b border-zinc-900 pb-2">
          <BarChart3 className="text-punk-accent" size={28} />
          <h2 className="text-2xl font-display uppercase tracking-wider">Competency Visualization</h2>
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16">
          {/* Left Col: The Chart */}
          <div className="bg-zinc-950/50 p-6 md:p-10 border border-zinc-900">
            <h3 className="text-xs font-bold uppercase text-zinc-500 mb-8 tracking-[0.3em] flex items-center gap-2">
              <span className="w-2 h-2 bg-punk-cyan rounded-full animate-pulse"></span>
              Core Pillars Mastery
            </h3>
            {SKILL_LEVELS.map((skill, idx) => (
              <SkillBar key={idx} label={skill.label} level={skill.level} color={skill.color} />
            ))}
          </div>

          {/* Right Col: Secondary Skills */}
          <div className="space-y-8">
            {SKILLS_DATA.slice(0, 2).map((group, idx) => (
              <div key={idx} className="relative">
                <h4 className="text-[10px] font-mono font-bold text-punk-cyan uppercase mb-4 tracking-widest flex items-center gap-2">
                  <Code size={12} /> {group.category}
                </h4>
                <div className="flex flex-wrap gap-2">
                  {group.items.map((item, iIdx) => (
                    <span key={iIdx} className="text-[10px] font-mono border border-zinc-800 bg-black text-zinc-400 px-2 py-1 hover:border-white hover:text-white transition-all cursor-default">
                      {item}
                    </span>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Education & Languages Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-12 mt-20 pt-10 border-t border-zinc-900">
          {/* Education */}
          <div className="lg:col-span-2">
            <div className="flex items-center gap-3 mb-8">
              <GraduationCap className="text-punk-cyan" size={24} />
              <h2 className="text-xl font-display uppercase tracking-wider">Education</h2>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {EDUCATION_DATA.map((edu) => (
                <div key={edu.id} className="bg-zinc-900/40 p-5 border border-zinc-900 group hover:border-punk-cyan transition-colors">
                  <h3 className="font-bold text-white text-sm leading-tight group-hover:text-punk-cyan">{edu.degree}</h3>
                  <p className="text-gray-500 font-mono text-[10px] mt-2 uppercase tracking-widest border-t border-zinc-800 pt-2 inline-block w-full">{edu.year}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Languages */}
          <div>
            <div className="flex items-center gap-3 mb-8">
              <Globe className="text-punk-yellow" size={24} />
              <h2 className="text-xl font-display uppercase tracking-wider">Languages</h2>
            </div>
            <div className="space-y-2">
              {[
                { lang: 'English', level: 'Fluent' },
                { lang: 'French', level: 'Fluent' },
                { lang: 'Arabic', level: 'Native' }
              ].map((l, idx) => (
                <div key={idx} className="flex justify-between items-center bg-zinc-950 p-4 border border-zinc-900 group hover:bg-zinc-900 transition-colors">
                  <span className="font-mono text-sm text-gray-300 uppercase tracking-tighter">{l.lang}</span>
                  <span className="text-punk-yellow font-bold text-[10px] font-mono tracking-widest">{l.level}</span>
                </div>
              ))}
            </div>
          </div>
      </div>

      <style>{`
        @keyframes move-scan {
          from { transform: translateX(-100%); }
          to { transform: translateX(500%); }
        }
      `}</style>
    </div>
  );
};

export default Resume;
