
import React, { useState } from 'react';
import { Project } from '../types';
import { ExternalLink, Heart, MessageSquare } from 'lucide-react';

interface PortfolioGridProps {
  items: Project[];
}

const PortfolioGrid: React.FC<PortfolioGridProps> = ({ items }) => {
  const [hoveredId, setHoveredId] = useState<number | null>(null);

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 max-w-6xl mx-auto p-6">
      {items.map((item) => (
        <div 
          key={item.id} 
          className="relative group cursor-pointer bg-zinc-950 border border-zinc-900 transition-all duration-500 hover:border-punk-cyan/50 hover:shadow-[0_0_30px_rgba(0,240,255,0.1)]"
          onMouseEnter={() => setHoveredId(item.id)}
          onMouseLeave={() => setHoveredId(null)}
        >
          {/* Visual Container */}
          <div className="aspect-[4/5] overflow-hidden relative">
            <img 
              src={item.image} 
              alt={item.title} 
              className="w-full h-full object-cover transition-transform duration-1000 group-hover:scale-110 contrast-[1.1]"
            />
            
            {/* Subtle Gradient Overlay (Always there) */}
            <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent opacity-60"></div>

            {/* Content Overlay on Hover */}
            <div className={`absolute inset-0 bg-punk-black/90 flex flex-col justify-end p-8 transition-all duration-300 ${hoveredId === item.id ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'}`}>
              <div className="mb-6">
                 <p className="text-xs font-mono text-punk-cyan mb-2 uppercase tracking-[0.2em]">Brief & Context</p>
                 <p className="text-sm font-mono text-gray-300 leading-relaxed italic">
                    "{item.description}"
                 </p>
              </div>
              
              <div className="flex flex-wrap gap-2 mb-6">
                {item.tags.map(tag => (
                  <span key={tag} className="text-[9px] border border-zinc-700 text-zinc-400 px-2 py-0.5 font-mono uppercase hover:border-punk-cyan hover:text-punk-cyan transition-colors">
                    #{tag}
                  </span>
                ))}
              </div>

              <div className="flex items-center gap-6 text-zinc-500 font-mono text-[10px] border-t border-zinc-800 pt-4">
                 <span className="flex items-center gap-1.5 hover:text-white transition-colors"><Heart size={14} className="text-punk-accent"/> {item.likes}</span>
                 <span className="flex items-center gap-1.5 hover:text-white transition-colors"><MessageSquare size={14} /> {item.comments}</span>
              </div>
            </div>
          </div>

          {/* Label Bar */}
          <div className="p-5 flex items-center justify-between bg-zinc-950">
            <div>
              <p className="text-[9px] font-mono text-punk-yellow font-bold uppercase tracking-[0.3em] mb-1.5">{item.category}</p>
              <h3 className="font-display text-2xl text-white uppercase tracking-tight group-hover:text-punk-cyan transition-colors duration-300">
                {item.title}
              </h3>
            </div>
            <div className="w-10 h-10 border border-zinc-800 flex items-center justify-center group-hover:bg-white group-hover:text-black transition-all duration-300">
               <ExternalLink size={16} />
            </div>
          </div>

          {/* Glitch Line Decor */}
          <div className="absolute top-0 left-0 w-0 h-[1px] bg-punk-cyan group-hover:w-full transition-all duration-700"></div>
        </div>
      ))}
    </div>
  );
};

export default PortfolioGrid;
