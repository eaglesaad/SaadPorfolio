
import React from 'react';
import { MapPin, Mail, Phone, Share2 } from 'lucide-react';

const ProfileHeader: React.FC = () => {
  // Direct image URL for the profile picture
  const profileImageUrl = "https://scontent-ord5-3.xx.fbcdn.net/v/t39.30808-6/375865452_10232542131845449_598249800005329949_n.jpg?_nc_cat=100&ccb=1-7&_nc_sid=a5f93a&_nc_ohc=1s2BqIh_F_UQ7kNvwHNYeiK&_nc_oc=AdnwVlMEuyLUmR0zV8bMN8pq20FOPSkoqwSizytqfTGthKP12XG1gI0e8nO2Jxl0A_c&_nc_zt=23&_nc_ht=scontent-ord5-3.xx&_nc_gid=1GKIMJDK3pC-Z8ot2xyOGQ&oh=00_AfspLLcKB5FZDojxQonw3m8A6ocubPrnkAdp_tubv_1EOg&oe=6989CCCA";

  return (
    <div className="w-full max-w-5xl mx-auto p-6 md:p-12">
      <div className="flex flex-col md:flex-row items-center gap-10">
        
        {/* Avatar / Brand Block */}
        <div className="relative group shrink-0">
          <div className="w-48 h-48 md:w-72 md:h-72 border-4 border-punk-cyan p-1 bg-black overflow-hidden relative shadow-[0_0_40px_rgba(0,240,255,0.15)]">
            {/* HUD Overlays */}
            <div className="absolute inset-0 bg-gradient-to-tr from-punk-accent/20 to-transparent z-20 pointer-events-none"></div>
            <div className="absolute inset-0 bg-[linear-gradient(rgba(18,16,16,0)_50%,rgba(0,0,0,0.1)_50%),linear-gradient(90deg,rgba(255,0,0,0.03),rgba(0,255,0,0.01),rgba(0,0,255,0.03))] z-20 pointer-events-none bg-[length:100%_2px,3px_100%]"></div>
            
            {/* The actual Image */}
            <img 
              src={profileImageUrl} 
              alt="Saad Lyafi" 
              className="w-full h-full object-cover transition-transform duration-1000 group-hover:scale-105"
            />

            {/* Corner Accents - Stylized HUD */}
            <div className="absolute top-2 left-2 w-4 h-4 border-t border-l border-punk-cyan z-30 opacity-70"></div>
            <div className="absolute top-2 right-2 w-4 h-4 border-t border-r border-punk-cyan z-30 opacity-70"></div>
            <div className="absolute bottom-2 left-2 w-4 h-4 border-b border-l border-punk-cyan z-30 opacity-70"></div>
            <div className="absolute bottom-2 right-2 w-4 h-4 border-b border-r border-punk-cyan z-30 opacity-70"></div>
            
            {/* Scanning Line Effect */}
            <div className="absolute top-0 left-0 w-full h-[1px] bg-punk-cyan/40 shadow-[0_0_15px_#00f0ff] z-30 animate-[scan_4s_linear_infinite] pointer-events-none"></div>
            
            {/* Resolution/Status Overlay */}
            <div className="absolute top-4 left-4 font-mono text-[8px] text-punk-cyan uppercase tracking-tighter opacity-50 z-30 hidden md:block">
              REC // 4K 60FPS<br/>
              ISO 400
            </div>
          </div>
          
          <div className="absolute -bottom-3 -right-3 bg-punk-accent text-white text-[10px] font-mono font-bold px-3 py-1 uppercase tracking-widest shadow-[4px_4px_0px_#000] z-40 flex items-center gap-2">
            <span className="w-1.5 h-1.5 bg-white rounded-full animate-ping"></span>
            Identity Verified
          </div>
        </div>

        {/* Core Info */}
        <div className="flex-1 text-center md:text-left">
          <div className="mb-4">
            <div className="inline-flex items-center gap-2 mb-2 px-3 py-1 bg-zinc-900/50 border border-zinc-800 rounded-full">
              <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
              <span className="text-[10px] font-mono text-zinc-400 uppercase tracking-widest">Available for hire in Toronto</span>
            </div>
            <h1 className="text-5xl md:text-7xl font-display uppercase tracking-tighter text-white leading-none mb-2">
              SAAD <span className="text-punk-cyan">LYAFI</span>
            </h1>
            <p className="text-punk-yellow font-mono text-sm font-bold tracking-[0.25em] uppercase">
              Graphic Designer • Social Media • AI Specialist
            </p>
          </div>

          <p className="text-gray-400 font-mono text-sm leading-relaxed max-w-2xl mb-8">
            Specializing in high-impact visual storytelling and <span className="text-white italic">AI-driven creative workflows</span>. 
            From viral social media campaigns in Morocco to automated production pipelines in Canada, I blend aesthetics with automation.
          </p>
          
          <div className="flex flex-wrap justify-center md:justify-start gap-6 text-xs font-mono text-gray-500 uppercase tracking-widest">
            <span className="flex items-center gap-2 text-punk-cyan"><MapPin size={14}/> Toronto, Canada</span>
            <a href="mailto:lyafisaad@gmail.com" className="flex items-center gap-2 hover:text-white transition-colors border-b border-transparent hover:border-white"><Mail size={14}/> lyafisaad@gmail.com</a>
            <a href="tel:6472346147" className="flex items-center gap-2 hover:text-white transition-colors border-b border-transparent hover:border-white"><Phone size={14}/> +1 (647) 234-6147</a>
          </div>
        </div>
      </div>

      <style>{`
        @keyframes scan {
          0% { top: 0%; opacity: 0; }
          10% { opacity: 1; }
          90% { opacity: 1; }
          100% { top: 100%; opacity: 0; }
        }
      `}</style>
    </div>
  );
};

export default ProfileHeader;
