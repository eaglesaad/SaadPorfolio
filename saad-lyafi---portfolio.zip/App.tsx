
import React, { useState } from 'react';
import { LayoutGrid, Bot, FileText, Instagram, Facebook, Mail, ArrowRight } from 'lucide-react';
import ProfileHeader from './components/ProfileHeader';
import PortfolioGrid from './components/PortfolioGrid';
import AIStudio from './components/AIStudio';
import Resume from './components/Resume';
import { PORTFOLIO_ITEMS } from './constants';
import { ViewState, NavItem } from './types';

const App: React.FC = () => {
  const [view, setView] = useState<ViewState>('portfolio');

  const navItems: NavItem[] = [
    { label: 'Work', id: 'portfolio', icon: <LayoutGrid size={18} /> },
    { label: 'AI Lab', id: 'ai-studio', icon: <Bot size={18} /> },
    { label: 'Resume', id: 'resume', icon: <FileText size={18} /> },
  ];

  return (
    <div className="min-h-screen bg-punk-black text-gray-100 font-sans selection:bg-punk-accent selection:text-white pb-20 md:pb-0">
      
      {/* Minimal Header */}
      <nav className="sticky top-0 z-50 bg-punk-black/80 backdrop-blur-xl border-b border-zinc-900">
        <div className="max-w-6xl mx-auto px-6 h-16 flex items-center justify-between">
          <div 
            className="font-display text-2xl tracking-tighter text-white cursor-pointer hover:text-punk-cyan transition-colors" 
            onClick={() => setView('portfolio')}
          >
            S<span className="text-punk-yellow">L</span>.
          </div>
          
          <div className="hidden md:flex gap-10">
            {navItems.map((item) => (
              <button
                key={item.id}
                onClick={() => setView(item.id)}
                className={`flex items-center gap-2 text-xs font-mono font-bold uppercase tracking-[0.2em] transition-all
                  ${view === item.id ? 'text-punk-cyan border-b-2 border-punk-cyan pb-1' : 'text-gray-500 hover:text-white'}
                `}
              >
                {item.label}
              </button>
            ))}
          </div>

          <a 
            href="mailto:lyafisaad@gmail.com" 
            className="hidden md:flex items-center gap-2 border border-white px-5 py-2 text-[10px] font-mono font-bold uppercase hover:bg-white hover:text-black transition-all"
          >
            Get In Touch <ArrowRight size={12}/>
          </a>
        </div>
      </nav>

      <main className="animate-in fade-in duration-700">
        {view === 'portfolio' && (
          <div className="space-y-4">
            <ProfileHeader />
            <div className="max-w-6xl mx-auto px-6">
               <div className="flex items-center gap-4 mb-4">
                  <h2 className="text-xs font-mono font-bold text-zinc-500 uppercase tracking-[0.3em]">Selected Case Studies</h2>
                  <div className="h-[1px] flex-1 bg-zinc-900"></div>
               </div>
            </div>
            <PortfolioGrid items={PORTFOLIO_ITEMS} />
          </div>
        )}

        {view === 'resume' && <Resume />}

        {view === 'ai-studio' && (
          <div className="pt-10">
            <AIStudio />
          </div>
        )}
      </main>

      {/* Footer */}
      <footer className="mt-20 border-t border-zinc-900 py-16 bg-black">
        <div className="max-w-6xl mx-auto px-6 flex flex-col items-center">
           <div className="mb-8">
              <span className="font-display text-4xl text-zinc-800">SAAD LYAFI</span>
           </div>
           
           <div className="flex gap-8 mb-10">
             <a href="mailto:lyafisaad@gmail.com" className="text-zinc-500 hover:text-punk-cyan transition-colors"><Mail size={24}/></a>
             <a href="https://www.facebook.com/photo/?fbid=10232542131925451&set=a.1581163138654" target="_blank" className="text-zinc-500 hover:text-punk-accent transition-colors"><Facebook size={24}/></a>
             <a href="https://www.instagram.com/saadlyafi/" target="_blank" className="text-zinc-500 hover:text-pink-500 transition-colors"><Instagram size={24}/></a>
           </div>

           <p className="text-zinc-700 text-[9px] font-mono text-center uppercase tracking-[0.4em] leading-loose">
             Toronto Based • Digital Content Specialist<br/>
             Designed for Performance & Impact<br/>
             © 2024 ALL RIGHTS RESERVED
           </p>
        </div>
      </footer>

      {/* Mobile Nav */}
      <div className="md:hidden fixed bottom-0 left-0 right-0 bg-black/90 backdrop-blur-lg border-t border-zinc-900 flex justify-around p-4 z-50">
        {navItems.map((item) => (
          <button
            key={item.id}
            onClick={() => setView(item.id)}
            className={`flex flex-col items-center gap-1 ${view === item.id ? 'text-punk-cyan' : 'text-zinc-600'}`}
          >
            {item.icon}
            <span className="text-[8px] font-mono font-bold uppercase tracking-widest">{item.label}</span>
          </button>
        ))}
      </div>
    </div>
  );
};

export default App;
